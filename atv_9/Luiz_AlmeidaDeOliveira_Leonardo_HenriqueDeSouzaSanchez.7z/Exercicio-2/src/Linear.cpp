#include "../include/Linear.hpp"

double Linear::func(double input) {
    return this->a * input + this->b;
}