#include "../include/Senoide.hpp"
#include "math.h"

double Senoide::func(double input) {
    return std::sin(input);
}
